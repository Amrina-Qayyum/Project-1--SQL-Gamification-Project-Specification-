USE Northwinds2024Student;
GO

-- =========================================================
-- Mystery Title: Vanishing Customers
-- Student Name: Amrina Qayyum
-- Database: Northwinds2024Student
--
-- Objective:
-- This mystery examines customer inactivity by identifying customers whose
-- most recent orders were placed a long time ago. It also compares inactivity
-- with customer value based on total order count.
--
-- Story / Narrative:
-- The sales team believes that some once-active customers are no longer placing orders.
-- Management wants to identify these customers and determine whether any valuable
-- customers are being lost. This mystery explores customer activity patterns and
-- highlights inactive customers who may require immediate business attention.
-- =========================================================


-- =========================
-- Section 1
-- Purpose:
-- This query identifies the most recent order date for each customer.
-- It provides a basic view of customer activity and helps detect customers
-- whose last order was placed a long time ago.
-- =========================
SELECT c.CustomerId,
       c.CustomerCompanyName,
       MAX(o.OrderDate) AS LastOrderDate
FROM Sales.Customer c
LEFT JOIN Sales.[Order] o
    ON c.CustomerId = o.CustomerId
GROUP BY c.CustomerId, c.CustomerCompanyName
ORDER BY LastOrderDate ASC;

-- Result Summary:
-- This result shows the last recorded order date for each customer.
-- Customers appearing at the top of the result have the oldest recorded activity
-- and may be inactive.
--
-- Screenshot Reference:
-- screenshots/Mystery04_Section1.png



-- =========================
-- Section 2
-- Purpose:
-- This query adds country information to the customer activity result.
-- It helps identify whether inactive customers are concentrated in certain regions.
-- =========================
SELECT c.CustomerId,
       c.CustomerCompanyName,
       c.CustomerCountry,
       MAX(o.OrderDate) AS LastOrderDate
FROM Sales.Customer c
LEFT JOIN Sales.[Order] o
    ON c.CustomerId = o.CustomerId
GROUP BY c.CustomerId, c.CustomerCompanyName, c.CustomerCountry
ORDER BY LastOrderDate ASC;

-- Result Summary:
-- This result shows inactive customers along with their country information.
-- It helps the business understand whether customer inactivity is linked to
-- specific geographic markets.
--
-- Screenshot Reference:
-- screenshots/Mystery04_Section2.png



-- =========================
-- Section 3
-- Purpose:
-- This query adds total order count to customer activity data.
-- It helps identify whether inactive customers were previously important
-- based on the number of orders they placed.
-- =========================
SELECT c.CustomerId,
       c.CustomerCompanyName,
       c.CustomerCountry,
       MAX(o.OrderDate) AS LastOrderDate,
       COUNT(o.OrderId) AS TotalOrders
FROM Sales.Customer c
LEFT JOIN Sales.[Order] o
    ON c.CustomerId = o.CustomerId
GROUP BY c.CustomerId, c.CustomerCompanyName, c.CustomerCountry
ORDER BY LastOrderDate ASC, TotalOrders DESC;

-- Result Summary:
-- This result shows both inactivity and customer importance.
-- Customers with old last order dates and high order counts may represent
-- important lost or at-risk business relationships.
--
-- Screenshot Reference:
-- screenshots/Mystery04_Section3.png



-- =========================
-- Section 4 - Final Optimized Query
-- Purpose:
-- This final query combines customer inactivity, country, and total order count
-- into one CTE-based result. It also calculates days inactive and assigns an
-- inactivity rank to help identify the most critical inactive customers.
-- =========================
WITH CustomerActivity AS (
    SELECT c.CustomerId,
           c.CustomerCompanyName,
           c.CustomerCountry,
           MAX(o.OrderDate) AS LastOrderDate,
           COUNT(o.OrderId) AS TotalOrders
    FROM Sales.Customer c
    LEFT JOIN Sales.[Order] o
        ON c.CustomerId = o.CustomerId
    GROUP BY c.CustomerId, c.CustomerCompanyName, c.CustomerCountry
)
SELECT *,
       DATEDIFF(DAY, LastOrderDate, (SELECT MAX(OrderDate) FROM Sales.[Order])) AS DaysInactive,
       ROW_NUMBER() OVER (ORDER BY LastOrderDate ASC) AS InactivityRank
FROM CustomerActivity
ORDER BY DaysInactive DESC, TotalOrders DESC;

-- Final Result Summary:
-- This final result measures inactivity in days and ranks customers according
-- to how long they have been inactive. It also keeps total order count visible,
-- making it easier to identify valuable customers who have stopped ordering.
--
-- Final Conclusion:
-- This mystery concludes that some inactive customers may still be highly valuable
-- based on their past order history. These customers should be prioritized for
-- re-engagement efforts and future business recovery strategies.
--
-- Screenshot Reference:
-- screenshots/Mystery04_Section4.png