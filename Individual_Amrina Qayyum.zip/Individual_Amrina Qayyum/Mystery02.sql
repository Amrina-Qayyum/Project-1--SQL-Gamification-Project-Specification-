USE Northwinds2024Student;
GO

-- =========================================================
-- Mystery Title: Discount Conspiracy
-- Student Name: Amrina Qayyum
-- Database: Northwinds2024Student
--
-- Objective:
-- This mystery investigates unusual discount behavior in order transactions.
-- The goal is to identify customers, employees, and order lines associated
-- with the highest discounts in the database.
--
-- Story / Narrative:
-- The finance team suspects that some order lines received unusually high discounts.
-- Management wants to know whether these discounts are linked to specific customers,
-- employees, or products. This mystery explores discount patterns in order to detect
-- suspicious discount activity and highlight the most extreme discount cases.
-- =========================================================


-- =========================
-- Section 1
-- Purpose:
-- This query identifies all order detail records where a discount was applied.
-- It provides the basic discount information, including order, product, price,
-- quantity, and discount percentage.
-- =========================
SELECT OrderId, ProductId, UnitPrice, Quantity, DiscountPercentage
FROM Sales.OrderDetail
WHERE DiscountPercentage > 0
ORDER BY DiscountPercentage DESC;

-- Result Summary:
-- This result shows all discounted order lines in descending order of discount percentage.
-- It helps identify the order lines that received the largest discounts and serves
-- as the starting point for deeper discount analysis.
--
-- Screenshot Reference:
-- screenshots/Mystery02_Section1.png



-- =========================
-- Section 2
-- Purpose:
-- This query joins order details with customer and employee information.
-- It helps identify which customers and employees are associated with discounted orders.
-- =========================
SELECT o.OrderId,
       c.CustomerCompanyName,
       e.EmployeeFirstName + ' ' + e.EmployeeLastName AS EmployeeName,
       od.ProductId,
       od.Quantity,
       od.DiscountPercentage
FROM Sales.[Order] o
JOIN Sales.Customer c
    ON o.CustomerId = c.CustomerId
JOIN HumanResources.Employee e
    ON o.EmployeeId = e.EmployeeId
JOIN Sales.OrderDetail od
    ON o.OrderId = od.OrderId
WHERE od.DiscountPercentage > 0
ORDER BY od.DiscountPercentage DESC;

-- Result Summary:
-- This result links discounted order lines to the responsible customer and employee.
-- It provides useful business context by showing who is connected to discount activity.
--
-- Screenshot Reference:
-- screenshots/Mystery02_Section2.png



-- =========================
-- Section 3
-- Purpose:
-- This query calculates the average discount received by each customer.
-- It helps identify customers who tend to receive higher discounts more frequently.
-- =========================
SELECT c.CustomerCompanyName,
       AVG(od.DiscountPercentage * 1.0) AS AvgDiscount,
       COUNT(*) AS DiscountedLines
FROM Sales.[Order] o
JOIN Sales.Customer c
    ON o.CustomerId = c.CustomerId
JOIN Sales.OrderDetail od
    ON o.OrderId = od.OrderId
WHERE od.DiscountPercentage > 0
GROUP BY c.CustomerCompanyName
ORDER BY AvgDiscount DESC;

-- Result Summary:
-- This result shows the average discount percentage and the number of discounted lines
-- for each customer. It helps identify which customers benefit most from discounting behavior.
--
-- Screenshot Reference:
-- screenshots/Mystery02_Section3.png



-- =========================
-- Section 4 - Final Optimized Query
-- Purpose:
-- This final query combines customer, employee, product, and discount amount
-- information into one result set. It ranks the most suspicious discount cases
-- based on discounted line amount.
-- =========================
WITH DiscountData AS (
    SELECT o.OrderId,
           c.CustomerCompanyName,
           e.EmployeeFirstName + ' ' + e.EmployeeLastName AS EmployeeName,
           od.ProductId,
           od.Quantity,
           od.UnitPrice,
           od.DiscountPercentage,
           od.DiscountedLineAmount
    FROM Sales.[Order] o
    JOIN Sales.Customer c
        ON o.CustomerId = c.CustomerId
    JOIN HumanResources.Employee e
        ON o.EmployeeId = e.EmployeeId
    JOIN Sales.OrderDetail od
        ON o.OrderId = od.OrderId
)
SELECT *,
       RANK() OVER (ORDER BY DiscountedLineAmount DESC) AS SuspicionRank
FROM DiscountData
WHERE DiscountPercentage > 0.1
ORDER BY SuspicionRank;

-- Final Result Summary:
-- This final result ranks highly discounted order lines by discounted line amount.
-- It provides a clear view of the most suspicious discount cases and identifies
-- the related customers, employees, and products.
--
-- Final Conclusion:
-- This mystery concludes that large discount amounts should be examined carefully,
-- especially when they appear repeatedly for certain customers or employees.
-- The highest-ranked cases deserve immediate business review.
--
-- Screenshot Reference:
-- screenshots/Mystery02_Section4.png