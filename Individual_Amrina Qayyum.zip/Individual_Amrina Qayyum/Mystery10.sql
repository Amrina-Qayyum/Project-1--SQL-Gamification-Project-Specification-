USE Northwinds2024Student;
GO

-- =========================================================
-- Mystery Title: Final Crime Board
-- Student Name: Amrina Qayyum
-- Database: Northwinds2024Student
--
-- Objective:
-- This mystery combines multiple business risk indicators, including discontinued
-- products, large discounts, and late deliveries. Its goal is to produce one
-- final risk-based overview to support business decision-making.
--
-- Story / Narrative:
-- Management wants a final business risk board that brings together different
-- warning signals in one place. Instead of analyzing discounts, shipping delays,
-- and product status separately, they want one combined view. This mystery merges
-- multiple risk factors in order to identify high-risk products that deserve
-- immediate business attention.
-- =========================================================


-- =========================
-- Section 1
-- Purpose:
-- This query identifies products that are discontinued.
-- It provides the first business risk signal for the final crime board.
-- =========================
SELECT ProductId, ProductName, UnitPrice, Discontinued
FROM Production.Product
WHERE Discontinued = 1;

-- Result Summary:
-- This result shows all products marked as discontinued.
-- These products are important because they may still appear in sales or
-- risk analysis despite no longer being active products.
--
-- Screenshot Reference:
-- screenshots/Mystery10_Section1.png



-- =========================
-- Section 2
-- Purpose:
-- This query identifies order detail lines with large discount values.
-- It provides the second business risk signal by highlighting strongly discounted items.
-- =========================
SELECT OrderId, ProductId, DiscountPercentage, DiscountedLineAmount
FROM Sales.OrderDetail
WHERE DiscountPercentage > 0.1;

-- Result Summary:
-- This result shows discounted order lines with large discount percentages.
-- These lines may indicate products involved in aggressive discounting behavior
-- and contribute to overall business risk.
--
-- Screenshot Reference:
-- screenshots/Mystery10_Section2.png



-- =========================
-- Section 3
-- Purpose:
-- This query identifies orders shipped later than the required date.
-- It provides the third business risk signal by highlighting shipment delays.
-- =========================
SELECT OrderId, RequiredDate, ShipToDate
FROM Sales.[Order]
WHERE ShipToDate > RequiredDate;

-- Result Summary:
-- This result shows all late-shipped orders in the database.
-- These delayed deliveries represent an operational risk factor that may affect
-- customer satisfaction and overall business performance.
--
-- Screenshot Reference:
-- screenshots/Mystery10_Section3.png



-- =========================
-- Section 4 - Final Optimized Query
-- Purpose:
-- This final query combines discount risk, late shipping risk, discontinued status,
-- and product revenue into one business risk board. It classifies products as
-- High Risk, Medium Risk, or Low Risk for final decision-making.
-- =========================
WITH DiscountRisk AS (
    SELECT ProductId,
           MAX(DiscountPercentage) AS MaxDiscountPercentage
    FROM Sales.OrderDetail
    GROUP BY ProductId
),
LateShippingRisk AS (
    SELECT od.ProductId,
           COUNT(DISTINCT o.OrderId) AS LateOrderCount
    FROM Sales.[Order] o
    JOIN Sales.OrderDetail od ON o.OrderId = od.OrderId
    WHERE o.ShipToDate > o.RequiredDate
    GROUP BY od.ProductId
),
RevenueRisk AS (
    SELECT p.ProductId,
           p.ProductName,
           p.Discontinued,
           p.UnitPrice,
           ISNULL(MAX(dr.MaxDiscountPercentage), 0) AS MaxDiscountPercentage,
           ISNULL(ls.LateOrderCount, 0) AS LateOrderCount,
           ISNULL(SUM(dbo.fn_CalculateNetRevenue(od.UnitPrice, od.Quantity, od.DiscountPercentage)), 0) AS TotalRevenue
    FROM Production.Product p
    LEFT JOIN Sales.OrderDetail od ON p.ProductId = od.ProductId
    LEFT JOIN DiscountRisk dr ON p.ProductId = dr.ProductId
    LEFT JOIN LateShippingRisk ls ON p.ProductId = ls.ProductId
    GROUP BY p.ProductId, p.ProductName, p.Discontinued, p.UnitPrice, ls.LateOrderCount
)
SELECT *,
       CASE
           WHEN Discontinued = 1 AND MaxDiscountPercentage > 15 THEN 'High Risk'
           WHEN LateOrderCount > 0 AND MaxDiscountPercentage > 10 THEN 'Medium Risk'
           ELSE 'Low Risk'
       END AS RiskStatus
FROM RevenueRisk
ORDER BY RiskStatus DESC, LateOrderCount DESC, MaxDiscountPercentage DESC;

-- Final Result Summary:
-- This final result combines multiple risk indicators into one ranked business view.
-- It shows product-level discount exposure, late shipment involvement, product status,
-- and revenue contribution in a single decision-ready table.
--
-- Final Conclusion:
-- This mystery concludes that business risk is multidimensional and should not be
-- judged by one factor alone. Products classified as High Risk or Medium Risk
-- deserve closer review because they combine discount pressure, shipment issues,
-- and product-related warning signals.
--
-- Screenshot Reference:
-- screenshots/Mystery10_Section4.png