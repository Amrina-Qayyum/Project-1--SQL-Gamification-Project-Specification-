USE Northwinds2024Student;
GO

-- =========================================================
-- Mystery Title: Freight Mystery
-- Student Name: Amrina Qayyum
-- Database: Northwinds2024Student
--
-- Objective:
-- This mystery examines freight charges across orders and shippers.
-- Its goal is to identify unusually expensive freight cases and compare them
-- with normal freight patterns across different shippers.
--
-- Story / Narrative:
-- The operations team has noticed that some orders carry unexpectedly high freight costs.
-- Management wants to know whether these cases are isolated or linked to specific shippers.
-- This mystery investigates freight values, shipper-level averages, and unusual freight gaps
-- in order to uncover the most expensive shipping cases.
-- =========================================================


-- =========================
-- Section 1
-- Purpose:
-- This query lists all orders with their freight values.
-- It provides a basic view of which orders have the highest freight charges.
-- =========================
SELECT OrderId, CustomerId, Freight
FROM Sales.[Order]
ORDER BY Freight DESC;

-- Result Summary:
-- This result shows all orders sorted by freight in descending order.
-- It highlights the orders with the highest freight costs and provides
-- a starting point for freight investigation.
--
-- Screenshot Reference:
-- screenshots/Mystery08_Section1.png



-- =========================
-- Section 2
-- Purpose:
-- This query adds customer and shipper information to the freight analysis.
-- It helps identify which customer and which shipper are connected to the
-- most expensive freight cases.
-- =========================
SELECT o.OrderId,
       c.CustomerCompanyName,
       s.ShipperCompanyName,
       o.Freight
FROM Sales.[Order] o
JOIN Sales.Customer c ON o.CustomerId = c.CustomerId
JOIN Sales.Shipper s ON o.ShipperId = s.ShipperId
ORDER BY o.Freight DESC;

-- Result Summary:
-- This result shows the relationship between freight cost, customer, and shipper.
-- It helps identify which business parties are connected to unusually costly shipments.
--
-- Screenshot Reference:
-- screenshots/Mystery08_Section2.png



-- =========================
-- Section 3
-- Purpose:
-- This query calculates average and maximum freight values for each shipper.
-- It helps compare general shipping cost behavior across shipping companies.
-- =========================
SELECT s.ShipperCompanyName,
       AVG(o.Freight) AS AvgFreight,
       MAX(o.Freight) AS MaxFreight
FROM Sales.[Order] o
JOIN Sales.Shipper s ON o.ShipperId = s.ShipperId
GROUP BY s.ShipperCompanyName
ORDER BY AvgFreight DESC;

-- Result Summary:
-- This result shows the average and highest freight value for each shipper.
-- It helps identify which shipper tends to handle more expensive shipments overall.
--
-- Screenshot Reference:
-- screenshots/Mystery08_Section3.png



-- =========================
-- Section 4 - Final Optimized Query
-- Purpose:
-- This final query compares each order's freight value against the average
-- freight handled by the same shipper. It also ranks orders by freight amount
-- and highlights the biggest freight gaps.
-- =========================
WITH FreightData AS (
    SELECT o.OrderId,
           c.CustomerCompanyName,
           s.ShipperCompanyName,
           o.Freight,
           AVG(o.Freight) OVER (PARTITION BY s.ShipperCompanyName) AS ShipperAvgFreight
    FROM Sales.[Order] o
    JOIN Sales.Customer c ON o.CustomerId = c.CustomerId
    JOIN Sales.Shipper s ON o.ShipperId = s.ShipperId
)
SELECT *,
       Freight - ShipperAvgFreight AS FreightGap,
       RANK() OVER (ORDER BY Freight DESC) AS FreightRank
FROM FreightData
ORDER BY FreightGap DESC;

-- Final Result Summary:
-- This final result shows each order's freight, the shipper average freight,
-- and the gap between the two values. It clearly identifies unusually expensive
-- shipments relative to shipper norms.
--
-- Final Conclusion:
-- This mystery concludes that some freight charges are significantly above
-- the average level handled by the same shipper. These high-gap cases may
-- require further investigation for shipping efficiency and cost control.
--
-- Screenshot Reference:
-- screenshots/Mystery08_Section4.png