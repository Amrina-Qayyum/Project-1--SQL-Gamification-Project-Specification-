USE Northwinds2024Student;
GO

-- =========================================================
-- Mystery Title: Late Shipment Files
-- Student Name: Amrina Qayyum
-- Database: Northwinds2024Student
--
-- Objective:
-- This mystery aims to identify orders that were shipped later than the
-- required date. It also evaluates customer impact, shipper involvement,
-- and shipment delay severity.
--
-- Story / Narrative:
-- The company has received complaints about delayed shipments.
-- Management wants to understand which orders were delivered late,
-- which customers were affected, and which shipper handled those orders.
-- This mystery investigates shipment timing and highlights the most serious
-- delay cases for business review.
-- =========================================================


-- =========================
-- Section 1
-- Purpose:
-- This query identifies all orders where the shipping date was later than
-- the required date. It provides the basic late shipment cases.
-- =========================
SELECT OrderId, OrderDate, RequiredDate, ShipToDate
FROM Sales.[Order]
WHERE ShipToDate > RequiredDate
ORDER BY ShipToDate DESC;

-- Result Summary:
-- This result shows all orders that were shipped after the required date.
-- It provides an initial view of shipment delay cases in the database.
--
-- Screenshot Reference:
-- screenshots/Mystery03_Section1.png



-- =========================
-- Section 2
-- Purpose:
-- This query joins the late orders with customer and shipper information.
-- It helps identify which customers were affected and which shipper was
-- responsible for the delayed shipment.
-- =========================
SELECT o.OrderId,
       c.CustomerCompanyName,
       s.ShipperCompanyName,
       o.OrderDate,
       o.RequiredDate,
       o.ShipToDate
FROM Sales.[Order] o
JOIN Sales.Customer c ON o.CustomerId = c.CustomerId
JOIN Sales.Shipper s ON o.ShipperId = s.ShipperId
WHERE o.ShipToDate > o.RequiredDate
ORDER BY o.ShipToDate DESC;

-- Result Summary:
-- This result connects late shipment cases with the affected customer
-- and the shipper that handled the order. It adds business context
-- to the delay problem.
--
-- Screenshot Reference:
-- screenshots/Mystery03_Section2.png



-- =========================
-- Section 3
-- Purpose:
-- This query calculates the delay duration in days for each late order.
-- It helps measure how serious each shipment delay was.
-- =========================
SELECT o.OrderId,
       c.CustomerCompanyName,
       s.ShipperCompanyName,
       DATEDIFF(DAY, o.RequiredDate, o.ShipToDate) AS DelayDays
FROM Sales.[Order] o
JOIN Sales.Customer c ON o.CustomerId = c.CustomerId
JOIN Sales.Shipper s ON o.ShipperId = s.ShipperId
WHERE o.ShipToDate > o.RequiredDate
ORDER BY DelayDays DESC;

-- Result Summary:
-- This result shows the number of days each late shipment was delayed.
-- It helps identify the most severe late delivery cases in the dataset.
--
-- Screenshot Reference:
-- screenshots/Mystery03_Section3.png



-- =========================
-- Section 4 - Final Optimized Query
-- Purpose:
-- This final query combines customer, shipper, and delay-day information
-- into one result set. It ranks the worst delays within each shipper group
-- to show which shippers had the most serious late shipment cases.
-- =========================
WITH LateOrders AS (
    SELECT o.OrderId,
           c.CustomerCompanyName,
           s.ShipperCompanyName,
           DATEDIFF(DAY, o.RequiredDate, o.ShipToDate) AS DelayDays
    FROM Sales.[Order] o
    JOIN Sales.Customer c ON o.CustomerId = c.CustomerId
    JOIN Sales.Shipper s ON o.ShipperId = s.ShipperId
    WHERE o.ShipToDate > o.RequiredDate
)
SELECT *,
       RANK() OVER (PARTITION BY ShipperCompanyName ORDER BY DelayDays DESC) AS WorstDelayByShipper
FROM LateOrders
ORDER BY DelayDays DESC;

-- Final Result Summary:
-- This final result ranks delayed shipments by shipper and delay duration.
-- It clearly shows which shipper handled the worst late shipment cases
-- and which customers experienced the most serious delays.
--
-- Final Conclusion:
-- This mystery concludes that shipment delays are not equally distributed.
-- Some shippers appear to be associated with more severe delays than others.
-- These late shipment cases should be reviewed to improve delivery performance.
--
-- Screenshot Reference:
-- screenshots/Mystery03_Section4.png