USE Northwinds2024Student;
GO

-- =========================================================
-- Mystery Title: Category Popularity Trap
-- Student Name: Amrina Qayyum
-- Database: Northwinds2024Student
--
-- Objective:
-- This mystery evaluates product demand and revenue within each category.
-- Its goal is to rank category leaders and understand which categories are
-- dominated by certain products in terms of sales quantity and revenue.
--
-- Story / Narrative:
-- The company wants to understand which categories are the strongest performers
-- and which products lead those categories. Management believes that some categories
-- may rely heavily on only a few products. This mystery investigates product popularity,
-- category-level ranking, and revenue dominance in order to reveal category dependence.
-- =========================================================


-- =========================
-- Section 1
-- Purpose:
-- This query calculates the total quantity sold for each product.
-- It provides an initial ranking of product popularity across the entire business.
-- =========================
SELECT p.ProductId,
       p.ProductName,
       SUM(od.Quantity) AS TotalQuantity
FROM Production.Product p
JOIN Sales.OrderDetail od
    ON p.ProductId = od.ProductId
GROUP BY p.ProductId, p.ProductName
ORDER BY TotalQuantity DESC;

-- Result Summary:
-- This result shows the total quantity sold for each product.
-- It helps identify the most popular products across all categories
-- before category-level analysis is added.
--
-- Screenshot Reference:
-- screenshots/Mystery09_Section1.png



-- =========================
-- Section 2
-- Purpose:
-- This query groups product demand by category and product.
-- It helps show which products are most popular inside each category.
-- =========================
SELECT c.CategoryName,
       p.ProductName,
       SUM(od.Quantity) AS TotalQuantity
FROM Production.Category c
JOIN Production.Product p ON c.CategoryId = p.CategoryId
JOIN Sales.OrderDetail od ON p.ProductId = od.ProductId
GROUP BY c.CategoryName, p.ProductName
ORDER BY c.CategoryName, TotalQuantity DESC;

-- Result Summary:
-- This result shows product-level demand inside each category.
-- It helps identify which products are driving category performance.
--
-- Screenshot Reference:
-- screenshots/Mystery09_Section2.png



-- =========================
-- Section 3
-- Purpose:
-- This query ranks products by quantity sold inside each category.
-- It helps determine category leaders and compare product dominance
-- within the same category.
-- =========================
WITH CategoryProductSales AS (
    SELECT c.CategoryName,
           p.ProductId,
           p.ProductName,
           SUM(od.Quantity) AS TotalQuantity
    FROM Production.Category c
    JOIN Production.Product p ON c.CategoryId = p.CategoryId
    JOIN Sales.OrderDetail od ON p.ProductId = od.ProductId
    GROUP BY c.CategoryName, p.ProductId, p.ProductName
)
SELECT *,
       RANK() OVER (PARTITION BY CategoryName ORDER BY TotalQuantity DESC) AS CategoryRank
FROM CategoryProductSales
ORDER BY CategoryName, CategoryRank;

-- Result Summary:
-- This result ranks products within each category according to total quantity sold.
-- It helps identify the leading products in each category and highlights
-- category-level competition among products.
--
-- Screenshot Reference:
-- screenshots/Mystery09_Section3.png



-- =========================
-- Section 4 - Final Optimized Query
-- Purpose:
-- This final query combines category, product, quantity sold, revenue,
-- and discontinued status into one ranked result set. It ranks products
-- by revenue within each category to provide the final business answer.
-- =========================
WITH CategoryProductSales AS (
    SELECT c.CategoryName,
           p.ProductId,
           p.ProductName,
           p.Discontinued,
           SUM(od.Quantity) AS TotalQuantity,
           SUM(dbo.fn_CalculateNetRevenue(od.UnitPrice, od.Quantity, od.DiscountPercentage)) AS TotalRevenue
    FROM Production.Category c
    JOIN Production.Product p ON c.CategoryId = p.CategoryId
    JOIN Sales.OrderDetail od ON p.ProductId = od.ProductId
    GROUP BY c.CategoryName, p.ProductId, p.ProductName, p.Discontinued
)
SELECT *,
       RANK() OVER (PARTITION BY CategoryName ORDER BY TotalRevenue DESC) AS RevenueRankInCategory
FROM CategoryProductSales
ORDER BY TotalRevenue DESC;

-- Final Result Summary:
-- This final result ranks category products according to total revenue
-- while still showing total quantity sold and discontinued status.
-- It highlights which products dominate each category in financial terms.
--
-- Final Conclusion:
-- This mystery concludes that some categories are strongly driven by only a few products.
-- The top-ranked category leaders are especially important to business performance,
-- and categories with weak diversity may require closer strategic monitoring.
--
-- Screenshot Reference:
-- screenshots/Mystery09_Section4.png